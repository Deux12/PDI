package com.example.myjardin;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Cards extends AppCompatActivity {

    TextView banana, sandia, papaya, coco, rabano, albaricoque, melocoton, perejil;
    CardView cdBanana, cdSandia, cdPapaya, cdCoco, cdRabano, cdAlabaricoque, cdMelocoton, cdPerejil;
    ImageView imgBanana, imgSandia, imgPapaya, imgCoco, imgRabano, imgAlbaricoque, imgMelocoton
            , imgPerejil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cards);

        //Ocultar toolbar
        getSupportActionBar().hide();

        Button crear = findViewById(R.id.crear);
        Button salir = findViewById(R.id.salir);

        //ImagesViews
        imgBanana = findViewById(R.id.imgbanana);
        imgSandia = findViewById(R.id.imgSandia);
        imgPapaya = findViewById(R.id.imgpapa);
        imgCoco = findViewById(R.id.imgcoco);
        imgRabano = findViewById(R.id.imgrabano);
        imgAlbaricoque = findViewById(R.id.imgalb);
        imgMelocoton = findViewById(R.id.imgmeloco);
        imgPerejil = findViewById(R.id.imgpere);

        //TextViews
        banana = findViewById(R.id.tvbanana);
        sandia = findViewById(R.id.tit);
        papaya = findViewById(R.id.tvpapaya);
        coco = findViewById(R.id.tvcoco);
        rabano = findViewById(R.id.tvrabano);
        albaricoque = findViewById(R.id.tvalabaricoque);
        melocoton = findViewById(R.id.tvmelocoton);
        perejil = findViewById(R.id.tvalabaricoque);

        //CardViews
        cdSandia = findViewById(R.id.card1);
        cdBanana = findViewById(R.id.card3);
        cdPapaya = findViewById(R.id.card8);
        cdCoco = findViewById(R.id.card4);
        cdRabano = findViewById(R.id.card2);
        cdAlabaricoque = findViewById(R.id.card5);
        cdMelocoton = findViewById(R.id.card6);
        cdPerejil = findViewById(R.id.card9);

        crear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inton = new Intent(Cards.this, MainActivity.class);
                startActivity(inton);
                finish();
            }
        });

        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //si solo se hace un click
        cdBanana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "banana");
                startActivity(intent);
            }
        });

        //si se mantiene presionado
        cdBanana.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdBanana.setEnabled(false);
                imgBanana.setImageResource(R.drawable.camera);
                banana.setText("Elemento Borrado");
                return true;
            }
        });

        cdSandia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "sandia");
                startActivity(intent);
            }
        });

        cdSandia.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdSandia.setEnabled(false);
                imgSandia.setImageResource(R.drawable.camera);
                sandia.setText("Elemento Borrado");
                return true;
            }
        });

        cdPapaya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "papaya");
                startActivity(intent);
            }
        });

        cdPapaya.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdPapaya.setEnabled(false);
                imgPapaya.setImageResource(R.drawable.camera);
                papaya.setText("Elemento Borrado");
                return true;
            }
        });

        cdCoco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "coco");
                startActivity(intent);
            }
        });

        cdCoco.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdCoco.setEnabled(false);
                imgCoco.setImageResource(R.drawable.camera);
                coco.setText("Elemento Borrado");
                return true;
            }
        });

        cdRabano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "rabano");
                startActivity(intent);
            }
        });

        cdRabano.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdRabano.setEnabled(false);
                imgRabano.setImageResource(R.drawable.camera);
                rabano.setText("Elemento Borrado");
                return true;
            }
        });

        cdAlabaricoque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "albaricoque");
                startActivity(intent);
            }
        });

        cdAlabaricoque.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdAlabaricoque.setEnabled(false);
                imgAlbaricoque.setImageResource(R.drawable.camera);
                albaricoque.setText("Elemento Borrado");
                return true;
            }
        });

        cdMelocoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "melocoton");
                startActivity(intent);
            }
        });

        cdMelocoton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdMelocoton.setEnabled(false);
                imgMelocoton.setImageResource(R.drawable.camera);
                melocoton.setText("Elemento Borrado");
                return true;
            }
        });

        cdPerejil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cards.this, ViewCard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("planta", "perejil");
                startActivity(intent);
            }
        });

        cdPerejil.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                cdPerejil.setEnabled(false);
                imgPerejil.setImageResource(R.drawable.camera);
                perejil.setText("Elemento Borrado");
                return true;
            }
        });
    }
}