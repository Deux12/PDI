package com.example.myjardin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_card);

        //Ocultar toolbar
        getSupportActionBar().hide();

        //Imágen a cambiar
        ImageView img = findViewById(R.id.img);

        //Titulos plantas
        TextView tit = findViewById(R.id.tit);

        //Descripciones plantas
        EditText descr = findViewById(R.id.descr);

        //Recibimos valores en la String valor de si se realiza la muerte o no
        String valor = getIntent().getExtras().getString("planta");

        //Búscamos la planta introducida
        switch(valor){
            case "banana":
                //Cambiamos la imágen
                img.setImageResource(R.drawable.imgbanana);
                //Cambiamos el título
                tit.setText("Banana");
                //Cambiamos la descripción
                descr.setText("La banana,1\u200B conocido también como banano, plátano,2\u200B guineo maduro, guineo, cambur o gualele, es un fruto comestible, de varios tipos de grandes plantas herbáceas del género Musa (de origen indomalayo). A estas plantas de gran porte que tienen aspecto de arbolillo se las denomina plataneras, bananeros, bananeras, plátanos o bananos.3\u200B\n" +
                        "\n" +
                        "Es un fruto con cualidades variables en tamaño, color y firmeza, alargado, generalmente curvado y carnoso, rico en almidón cubierto con una cáscara, que puede ser verde, amarilla, roja, púrpura o marrón cuando está madura. Los frutos crecen en piñas que cuelgan de la parte superior de la planta. Casi todos los plátanos en la actualidad son frutos estériles que no producen semillas fructificantes y provienen de dos especies silvestres: Musa acuminata y Musa balbisiana. El nombre científico de la mayoría de los plátanos cultivados es Musa × paradisiaca, el híbrido Musa acuminata × M. balbisiana, con distintas denominaciones var. o cultivares, dependiendo de su constitución genómica.");
                break;
            case "sandia":
                tit.setText("Sandía");
                descr.setText("Es una planta herbácea de ciclo anual, trepadora o rastrera, de textura áspera, con tallos pilosos provistos de zarcillos y hojas de cinco lóbulos profundos. Las flores son amarillas, grandes y unisexuales, las femeninas tienen el gineceo con tres carpelos, y las masculinas con cinco estambres.\n" +
                        "\n" +
                        "El fruto de la planta es grande (normalmente más de cuatro kilos), pepónide, carnoso y jugoso (más del 90% es agua), casi esférico, de textura lisa y sin porosidades, de color verde en dos o más tonos. La pulpa es de color rojo —por el antioxidante licopeno— y de carne de sabor generalmente dulce (más raramente amarilla y amarga).\n" +
                        "\n" +
                        "Las numerosas semillas pueden llegar a medir 1 cm de longitud, son de color negro, marrón o blanco y ricas en vitamina E, se han utilizado en medicina popular y también se consumen tostadas como alimento.");
                break;
            case "papaya":
                img.setImageResource(R.drawable.imgpapaya);
                tit.setText("Papaya");
                descr.setText("Se trata de una verdura tronco generalmente no ramificado (sólo se ramifica si dicho tronco es herido), cultivado presenta una altura entre 1,9 y 2,5 m coronado por un follaje de hojas largamente pecioladas. El mismo conserva aún en los individuos maduros una textura suculenta y turgente, escasamente leñosa, y presenta numerosas cicatrices características, producto del crecimiento y caída consecutivas de las hojas. La savia es de consistencia lechosa (de aquí su nombre de «lechosa»), y tóxica en estado natural para el humano, pudiendo producir irritaciones alérgicas con el contacto con la piel. Esta savia lechosa contiene una enzima muy útil, la papaína, empleada como ablandador de carnes: en las parrillas o barbacoas se emplea el jugo que fluye al cortar la corteza de la papaya verde para rociarlo sobre la carne a la cual deja sumamente tierna y jugosa.");
                break;
            case "coco":
                img.setImageResource(R.drawable.imgcoco);
                tit.setText("Coco");
                descr.setText("El coco es una fruta (drupa) obtenida principalmente de la especie tropical cocotero (Cocos nucifera), la palmera más cultivada a nivel mundial. Sus flores son poligamonoecias.1\u200B Tiene una cáscara exterior gruesa (exocarpio), una capa intermedia fibrosa (mesocarpio) y otra interior dura, vellosa y marrón (endocarpio); que tiene adherida la pulpa blanca y aromática (endospermo). Mide de 20 a 30 cm y llega a pesar 2.6 kg.\n" +
                        "\n" +
                        "El principal producto exportado desde las distintas zonas de cultivo es la copra sin procesar, seguida del coco desecado. En ciertos países europeos, encuentra su mejor salida el coco fresco; el protagonista indiscutible de ferias y verbenas y de común uso en múltiples preparaciones de repostería artesanal e industrial. El mercado más interesante tanto en Asia como en Europa y Norteamérica es el del agua de coco envasada; de gran aceptación y mayor demanda cada año.");
                break;
            case "perejil":
                img.setImageResource(R.drawable.imgperejil);
                tit.setText("Perejil");
                descr.setText("Planta herbácea bienal, aunque puede cultivarse también como anual. Forma una roseta empenachada de hojas muy divididas, alcanza los 30 cm de altura y posee tallos floríferos que pueden llegar a rebasar los 60 cm con pequeñas flores verde amarillentas y negras.\n" +
                        "\n" +
                        "Su cultivo se conoce desde hace más de tres mil años, siendo una de las plantas aromáticas más populares de la gastronomía mundial.\n" +
                        "\n" +
                        "La variedad perejil grande Petroselinum sativum tuberosum, posee una raíz engrosada axonomorfa, parecida a la chirivía, que es la que se consume como hortaliza cruda o cocinada. Esta variedad tiene hojas más grandes y rugosas que las del perejil común y más similares a la especie silvestre.");
                break;
            case "albaricoque":
                img.setImageResource(R.drawable.imgalbaricoque);
                tit.setText("Albaricoque");
                descr.setText("El albaricoquero es un árbol pequeño, de 8 a 12 m de altura, con un tronco de hasta 40 cm de diámetro y una copa densa y extendida. Las hojas son ovadas, de 5 a 9 cm de largo y de 4 a 8 cm de ancho, con una base redondeada, una punta puntiaguda y un margen finamente dentado. Las flores miden de 2 a 4,5 cm de diámetro, con cinco pétalos de color blanco a rosado; se producen de forma individual o en parejas a principios de la primavera antes de las hojas. El fruto es una drupa (fruta de hueso) similar a un melocotón pequeño, de 1,5 a 2,5 cm de diámetro —aunque más grande en algunas plantaciones modernas—, con un color desde amarillo hasta naranja, a menudo teñido de rojo en el lado más expuesto al sol; su superficie puede ser lisa (botánicamente descrita como glabra) o aterciopelada con vellosidades cortas. La pulpa suele ser empleada como alimento, pero en algunas especies como P. sibirica es seca. Su sabor puede variar de dulce a ácido. La semilla única está encerrada en una cáscara dura, con una textura granulosa y suave, excepto por tres crestas que corren por un lado.");
                break;
            case "melocoton":
                img.setImageResource(R.drawable.imgmelocoton);
                tit.setText("Melocotón");
                descr.setText("Árbol de hasta 6-8 m de altura, caducifolio e inerme. Las hojas son oblongas-lanceoladas o elípticas, acuminadas, cuneadas en la base, aserradas con dientes glandulíferos, glabrescentes, con estípulas caducas denticuladas. Las flores son solitarias o geminadas y con numerosas brácteas. Los sépalos son erectos enteros y los pétalos denticulados en el ápice, de color rosado fuerte. El ovario puede ser pubescente o glabro y el fruto derivado, de 4-8 cm de diámetro, es una drupa comestible subglobosa con mesocarpo muy carnoso y endocarpo (hueso) profundamente surcado y alveolado con una sola semilla almendroide no comestible,9\u200B debido a la presencia, aunque en pequeña cantidad, de un precursor del cianuro, la amigdalina: un compuesto de glucosa, benzaldehído y cianuro que, bajo la acción de un fermento (emulsina) se descompone, produciendo ácido cianhídrico, potencialmente mortal.10\u200B Por tal motivo, su semilla es tóxica.");
                break;
            case "rabano":
                img.setImageResource(R.drawable.imgrabano);
                tit.setText("Rábano");
                descr.setText("Planta anual o bienal de raíz axonomorfa. Tallo de 20-100 cm, erecto, poco ramificado, glabro o algo hispido en la base. Hojas basales de hasta 30cm, pecioladas, en rosetas, lirado-pinnatisectas, con 2-3 pares de segmentos laterales y uno terminal de mayor tamaño, sub-orbicular; las superiores, de ovadas a oblongo-lanceoladas. Racimos de 10-50 flores con pedicelos de 5-15 mm en la antesis, 10-30 en la fortificación. Sépalos de 6-11 mm y pétalos 15-20 mm, blanco-rosados o violetas más o menos veteados. Los frutos son silicuas indehiscentes de 30-60 por 6-12 mm, erecto-patentes con artejo valvar residual de 1,5-2,5 mm, sin semilla, raramente monospermo y el superior de 25-70 por 8-15 mm, cilíndrico, longitudinalmente estriado, con 2-10 semillas y terminado en un pico cónico de 10-15 mm. Dichas semillas, de 3-4 mm, de contorno elipsoidal truncado, reticulada-estriadas y de color verde cuando son inmaduras y que se tornan pardas en la madurez, están inmersas en un tupido tejido esponjoso blanco que se desarrolla durante esta maduración. ");
                break;
        }
    }
}